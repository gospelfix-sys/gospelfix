# CLAUDE.md

이 파일은 Claude Code가 이 프로젝트에서 작업할 때 매 세션 자동으로 읽는 프로젝트 맥락입니다.
아래 항목을 여러분의 프로젝트에 맞게 채워 넣으세요.

## 기술 스택

- 프레임워크: (예: Next.js 14, App Router)
- 스타일링: (예: Tailwind CSS)
- 상태 관리: (예: Recoil, Zustand)
- 패키지 매니저: (예: yarn — npm install 금지)

## 자주 쓰는 명령어

```bash
yarn dev      # 개발 서버
yarn build    # 프로덕션 빌드
yarn lint     # 린트
```

## 코딩 컨벤션

- 따옴표: (예: 쌍따옴표만 사용)
- 세미콜론: (예: 항상 붙임)
- 인라인 style 속성: (예: 금지, className만 사용)
- className 병합: (예: cn() 유틸 사용)

## 폴더 구조 참고

- `components/ui/` — 공용 UI 프리미티브
- `components/[domain]/` — 도메인별 기능 컴포넌트
- `app/**/page.tsx` — 라우트 단위 페이지

이 섹션들을 실제 프로젝트 구조로 바꾸면, Claude Code가 다음 세션부터 이 규칙을 자동으로
따릅니다.
