---
name: fix-issue
argument-hint: [issue-number]
---

이슈 #$ARGUMENTS 를 처리합니다.

1. `gh issue view $ARGUMENTS`로 이슈 내용을 확인합니다.
2. 관련 코드 위치를 찾습니다.
3. 수정하고, 필요하면 테스트를 추가합니다.
4. "fix: #$ARGUMENTS ..." 형식으로 커밋 메시지를 작성합니다.
