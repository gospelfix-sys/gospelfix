# Claude Code 스타터 킷 (by GOSPELFIX)

GOSPELFIX에서 구매한 Next.js 템플릿을 Claude Code로 바로 커스터마이징할 수 있도록 만든
`.claude/` 폴더 예시입니다. 이 폴더 전체를 여러분의 프로젝트 루트에 그대로 복사하세요.

## 사용법

1. `.claude/` 폴더를 프로젝트 루트(`package.json`이 있는 위치)에 복사합니다.
2. `.claude/CLAUDE.md`를 열어 실제 사용 중인 기술 스택, 명령어, 코딩 컨벤션으로 내용을
   바꿔줍니다.
3. `.claude/rules/frontend.md`를 프로젝트의 실제 스타일 규칙(Tailwind 설정, 컴포넌트 위치
   등)에 맞게 수정합니다.
4. Claude Code를 실행하면 이 폴더의 내용을 자동으로 읽어 프로젝트 맥락을 파악합니다.

## 포함된 파일

- `.claude/CLAUDE.md` — 프로젝트 전체 맥락 (기술 스택, 명령어, 컨벤션)
- `.claude/agents/code-reviewer.md` — 코드 리뷰 전담 에이전트 예시
- `.claude/commands/fix-issue.md` — 이슈 처리 자동화 커맨드 예시
- `.claude/rules/frontend.md` — 프론트엔드 코딩 규칙 예시
- `.claude/settings.json` — 권한/훅 설정 예시

각 파일 안의 내용은 예시입니다 — 여러분의 프로젝트에 맞게 자유롭게 수정해서 쓰세요.

더 자세한 설명은 GOSPELFIX 블로그의 "Claude Code로 템플릿을 커스터마이징하는 팀은
이렇게 세팅합니다" 글을 참고하세요.
